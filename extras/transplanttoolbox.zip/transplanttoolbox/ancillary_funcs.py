
#! usr/bin/python

import re






def group_serotypes_per_locus(ag_list):
	a_locus_ag = []
	b_locus_ag = []
	c_locus_ag = []
	dr_locus_ag = []
	dq_locus_ag = []

	for ag in ag_list:
		if re.findall("A", ag):
			a_locus_ag.append(ag)

		if re.findall("B", ag):
			b_locus_ag.append(ag)

		if re.findall("C", ag):
			c_locus_ag.append(ag)

		if re.findall("DR", ag):
			dr_locus_ag.append(ag)		
		
		if re.findall("DQ", ag):
			dq_locus_ag.append(ag)		

	locus_sorted_ag_list = [", ".join(sorted(a_locus_ag))] + [", ".join(sorted(b_locus_ag))] + [", ".join(sorted(c_locus_ag))] + [", ".join(sorted(dr_locus_ag))] + [", ".join(sorted(dq_locus_ag))]


	return locus_sorted_ag_list	




def split_gl_string_per_locus(gl_string):
	a_string = ""
	b_string = ""
	c_string = ""
	dr_string = ""
	dq_string = ""

	gl_string_split = gl_string.split("^")	

	for string in gl_string_split:
		if string.startswith("A"):
			a_string = string.replace("+", " + ") 
			a_string = a_string.replace("/", "/ ")

		if string.startswith("B"):
			b_string = string.replace("+", " + ") 
			b_string = b_string.replace("/", "/ ")

		if string.startswith("C"):
			c_string = string.replace("+", " + ")
			c_string = c_string.replace("/", "/ ") 

		if string.startswith("DR"):
			dr_string = string.replace("+", " + ") 
			dr_string = dr_string.replace("/", "/ ")

		if string.startswith("DQ"):
			dq_string = string.replace("+", " + ") 
			dq_string = dq_string.replace("/", "/ ") 



	string_list = [a_string] + [b_string] + [c_string] + [dr_string] + [dq_string]	
	
	return string_list				





def prob_dict_list_of_strings(allele_probs):

	a_alleles = [] 
	b_alleles = []
	c_alleles = []
	dr_alleles = []
	dq_alleles = []


	for i,j in allele_probs.items():
		if i.startswith("A"):
			ji = str(j)
			fi = i + ": " + ji
			a_alleles.append(fi)

		if i.startswith("B"):
			ji = str(j)
			fi = i + ": " + ji 
			b_alleles.append(fi)


		if i.startswith("C"):
			ji = str(j)
			fi = i + ": " + ji 
			c_alleles.append(fi)

		if i.startswith("DQ"):
			ji = str(j)
			fi = i + ": " + ji 
			dq_alleles.append(fi)       

		if i.startswith("DR"):
			ji = str(j)
			fi = i + ": " + ji 
			dr_alleles.append(fi)



	list_of_allele_probs = [a_alleles] + [b_alleles] + [c_alleles] + [dr_alleles] + [dq_alleles] 

	return list_of_allele_probs



def group_allele_codes_or_list_of_alleles_per_locus(donor_typing_list):
	donor_a_alleles = []
	donor_b_alleles = []
	donor_c_alleles = []
	donor_dr_alleles = []
	donor_dq_alleles = []
	

	for i in donor_typing_list:
		locus = i.split("*")[0]
		if locus == "A":
			donor_a_alleles.append(i)

		if locus == "B":
			donor_b_alleles.append(i)

		if locus == "C":
			donor_c_alleles.append(i)

		if (locus == "DRB1") or (locus == "DRB3") or (locus == "DRB4") or (locus == "DRB5"):
			donor_dr_alleles.append(i)

		if (locus == "DQB1") or (locus == "DQA1"):
			donor_dq_alleles.append(i)


	final_typing_list = [", ".join(sorted(donor_a_alleles))] + [", ".join(sorted(donor_b_alleles))] + [", ".join(sorted(donor_c_alleles))] + [", ".join(sorted(donor_dr_alleles))] + [", ".join(sorted(donor_dq_alleles))] 

	return final_typing_list
