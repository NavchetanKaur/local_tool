
var allele_list = "B"