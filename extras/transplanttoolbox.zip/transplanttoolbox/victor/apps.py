from django.apps import AppConfig


class VictorConfig(AppConfig):
    name = 'victor'
