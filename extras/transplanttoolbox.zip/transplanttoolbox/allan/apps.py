from django.apps import AppConfig


class AllanConfig(AppConfig):
    name = 'allan'
